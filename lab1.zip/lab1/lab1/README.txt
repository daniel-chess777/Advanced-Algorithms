Explanation and Theory:

Graph Representation: The graph is represented using an adjacency list, which is 
efficient in terms of space especially if the graph is sparse.

BFS Algorithm: Breadth-First Search (BFS) starts at the root node and explores 
all the neighboring nodes at the present depth prior to moving on to nodes at 
the next depth level. This is implemented using a queue. It ensures all vertices 
are visited and works correctly due to its systematic level-by-level exploration.

DFS Algorithm: Depth-First Search (DFS) explores as far down a branch as possible 
before backtracking. This is implemented using recursion. It works correctly by 
exploring each vertex and its adjacent vertices deeply before moving to the next 
vertex, ensuring all vertices are visited.

The "6 6" in the sample input specifies the structure of the graph 
(6 vertices, 6 edges) but is not used directly in the code; instead, it informs 
the setup of the graph. This is why the number of vertices is hardcoded when the 
Graph object is instantiated.
